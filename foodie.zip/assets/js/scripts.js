(function($) {
  "use strict";



}(jQuery));
