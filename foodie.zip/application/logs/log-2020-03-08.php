<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-08 00:00:05 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-08 00:00:09 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-08 00:00:20 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-08 00:00:56 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-08 00:01:31 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-08 00:02:28 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-08 00:03:19 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-08 00:03:30 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-08 00:26:16 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-08 00:26:24 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-08 00:26:29 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-08 00:26:37 --> Severity: error --> Exception: Unable to locate the model you have specified: User C:\xampp\htdocs\foodie\system\core\Loader.php 348
ERROR - 2020-03-08 00:28:13 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-08 00:28:21 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-08 00:28:28 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-08 00:28:41 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-08 00:29:34 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-08 00:42:56 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-08 00:42:56 --> Severity: Notice --> Undefined property: stdClass::$menu_id C:\xampp\htdocs\foodie\application\controllers\Admin.php 210
ERROR - 2020-03-08 00:45:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-08 00:47:04 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-08 00:48:03 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-08 00:48:24 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-08 00:48:31 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-08 00:48:47 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-08 00:49:04 --> Severity: Notice --> Undefined variable: dataCount C:\xampp\htdocs\foodie\application\views\menu.php 7
ERROR - 2020-03-08 00:49:06 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-08 00:56:21 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-08 01:10:39 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-08 01:11:50 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-08 01:11:53 --> 404 Page Not Found: User_api/order_menu
ERROR - 2020-03-08 01:13:31 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-08 01:16:06 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-08 01:18:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-08 01:23:07 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-08 01:23:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-08 01:23:24 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-08 01:23:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-08 01:28:37 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-08 01:28:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-08 01:32:12 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-08 01:32:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-08 01:35:25 --> Severity: Notice --> Undefined index: date_created C:\xampp\htdocs\foodie\application\views\user\order.php 16
ERROR - 2020-03-08 01:35:28 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-08 01:35:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-08 01:36:33 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-08 01:36:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-08 01:39:05 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-08 01:39:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-08 01:48:16 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-08 01:48:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-08 01:50:42 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-08 01:50:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-08 01:59:56 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-08 01:59:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-08 02:00:08 --> Severity: error --> Exception: Call to undefined method User_model::date_update() C:\xampp\htdocs\foodie\application\controllers\User_api.php 71
ERROR - 2020-03-08 02:02:42 --> Severity: Notice --> Undefined index: title C:\xampp\htdocs\foodie\application\views\user\order.php 14
ERROR - 2020-03-08 02:02:42 --> Severity: Notice --> Undefined index: price C:\xampp\htdocs\foodie\application\views\user\order.php 15
ERROR - 2020-03-08 02:02:42 --> Severity: Notice --> Undefined index: date_ordered C:\xampp\htdocs\foodie\application\views\user\order.php 16
ERROR - 2020-03-08 02:02:42 --> Severity: Notice --> Undefined index: description C:\xampp\htdocs\foodie\application\views\user\order.php 17
ERROR - 2020-03-08 02:02:42 --> Severity: Notice --> Undefined index: order_id C:\xampp\htdocs\foodie\application\views\user\order.php 27
ERROR - 2020-03-08 02:02:45 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-08 02:04:42 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-08 02:05:13 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-08 02:05:29 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-08 02:09:45 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-08 02:10:08 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-08 02:10:47 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-08 02:11:18 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-08 02:12:24 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-08 02:14:03 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\foodie\application\controllers\Account.php 85
ERROR - 2020-03-08 02:14:03 --> Severity: Notice --> Undefined property: mysqli::$menu_id C:\xampp\htdocs\foodie\application\controllers\Account.php 87
ERROR - 2020-03-08 02:14:03 --> Severity: Notice --> Undefined property: mysqli_result::$menu_id C:\xampp\htdocs\foodie\application\controllers\Account.php 87
ERROR - 2020-03-08 02:14:03 --> Severity: Notice --> Trying to get property 'menu_id' of non-object C:\xampp\htdocs\foodie\application\controllers\Account.php 87
ERROR - 2020-03-08 02:14:03 --> Severity: Notice --> Trying to get property 'menu_id' of non-object C:\xampp\htdocs\foodie\application\controllers\Account.php 87
ERROR - 2020-03-08 02:14:03 --> Severity: Notice --> Trying to get property 'menu_id' of non-object C:\xampp\htdocs\foodie\application\controllers\Account.php 87
ERROR - 2020-03-08 02:14:03 --> Severity: Notice --> Trying to get property 'menu_id' of non-object C:\xampp\htdocs\foodie\application\controllers\Account.php 87
ERROR - 2020-03-08 02:14:03 --> Severity: Notice --> Trying to get property 'menu_id' of non-object C:\xampp\htdocs\foodie\application\controllers\Account.php 87
ERROR - 2020-03-08 02:14:03 --> Severity: Notice --> Trying to get property 'menu_id' of non-object C:\xampp\htdocs\foodie\application\controllers\Account.php 87
ERROR - 2020-03-08 02:14:07 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-08 02:14:41 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-08 02:15:22 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-08 02:15:27 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-08 02:16:15 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-08 02:22:59 --> Severity: Notice --> Undefined index: title C:\xampp\htdocs\foodie\application\views\user\billing.php 23
ERROR - 2020-03-08 02:22:59 --> Severity: Notice --> Undefined index: data_billed C:\xampp\htdocs\foodie\application\views\user\billing.php 25
ERROR - 2020-03-08 02:22:59 --> Severity: Notice --> Undefined index: title C:\xampp\htdocs\foodie\application\views\user\billing.php 23
ERROR - 2020-03-08 02:22:59 --> Severity: Notice --> Undefined index: data_billed C:\xampp\htdocs\foodie\application\views\user\billing.php 25
ERROR - 2020-03-08 02:23:02 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-08 02:23:24 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-08 02:31:00 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-08 02:32:09 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-08 02:32:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-08 02:40:32 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-08 02:42:12 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-08 02:42:32 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-08 02:44:56 --> 404 Page Not Found: Assets/images
