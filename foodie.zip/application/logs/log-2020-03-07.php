<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-07 03:56:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 03:56:51 --> 404 Page Not Found: Admin/view_menu
ERROR - 2020-03-07 04:31:10 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 04:31:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 04:31:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 04:31:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 04:31:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 04:32:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 04:32:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 04:32:07 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 04:32:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 04:32:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 04:33:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 04:33:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 04:33:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 04:33:41 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 04:33:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 04:36:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 04:36:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 04:36:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 04:36:15 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 04:36:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 04:37:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 04:37:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 04:37:35 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 04:37:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 04:37:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 04:37:40 --> 404 Page Not Found: Admin/view_menu
ERROR - 2020-03-07 04:42:23 --> 404 Page Not Found: Admin/view_menu
ERROR - 2020-03-07 04:43:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 04:43:31 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 04:43:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 04:43:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 04:43:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 04:52:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 04:52:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 04:52:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 04:52:36 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 04:52:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 05:05:15 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 05:05:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 05:05:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 05:05:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 05:05:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 05:06:02 --> Query error: Unknown column 'name' in 'field list' - Invalid query: SELECT name, id FROM users WHERE name LIKE '%%' ESCAPE '!' ORDER BY name ASC LIMIT 20
ERROR - 2020-03-07 05:13:34 --> Query error: Unknown column 'name' in 'where clause' - Invalid query: SELECT concat(first_name, ' ', last_name) AS name, id FROM users WHERE name LIKE '%%' ESCAPE '!' ORDER BY name ASC LIMIT 20
ERROR - 2020-03-07 05:33:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 05:41:54 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 05:41:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 05:41:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 05:41:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 05:41:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 05:47:07 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 05:47:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 05:47:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 05:47:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 05:47:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 05:58:36 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 05:58:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 05:58:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 05:58:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 05:58:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 05:59:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 05:59:45 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 05:59:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 05:59:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 05:59:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 06:00:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 06:00:22 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 06:00:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 06:00:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 06:00:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 06:01:33 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 06:01:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 06:01:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 06:01:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 06:01:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 06:02:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 06:02:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 06:02:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 06:02:32 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 06:02:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 06:02:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 06:02:54 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 06:02:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 06:02:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 06:02:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 06:03:35 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 06:03:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 06:03:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 06:03:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 06:03:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 06:09:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 06:09:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 06:09:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 06:09:21 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 06:16:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 06:16:04 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 06:16:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 06:16:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 06:24:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 06:24:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 06:24:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 06:24:12 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 06:25:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 06:25:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 06:25:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 06:25:02 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 06:25:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 06:25:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 06:25:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 06:25:34 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 06:26:02 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 06:26:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 06:26:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 06:26:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 06:27:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 06:27:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 06:27:26 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 06:27:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 06:27:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 06:27:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 06:27:53 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 06:27:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 06:29:05 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 06:29:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 06:29:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 06:29:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 06:31:30 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 06:31:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 06:31:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 06:31:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 06:35:47 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 06:35:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 06:35:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 06:35:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 06:36:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 06:36:41 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 06:36:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 06:36:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 06:38:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 06:38:36 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 06:38:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 06:38:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 06:39:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 06:39:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 06:39:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 06:39:12 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 06:41:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 06:41:59 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 06:41:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 06:41:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 06:46:21 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 06:46:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 06:46:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 06:46:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 06:46:53 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 06:46:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 06:46:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 06:46:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 09:21:18 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 09:21:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 09:21:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 09:21:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 09:22:00 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 09:22:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 09:22:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 09:22:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 09:22:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 09:22:22 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 09:22:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 09:22:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 09:22:30 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 09:22:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 09:22:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 09:22:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 09:22:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 09:22:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 09:22:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 09:22:41 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 09:22:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 09:22:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 09:22:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 09:22:50 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 09:23:34 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 09:23:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 09:23:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 09:23:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 09:24:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 09:24:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 09:24:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 09:24:25 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 09:26:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 09:26:46 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 09:26:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 09:26:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 09:28:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 09:28:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 09:28:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 09:28:05 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 09:31:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 09:31:46 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 09:31:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 09:31:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 09:32:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 09:32:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 09:32:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 09:32:29 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 09:32:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 09:32:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 09:32:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 09:32:33 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 09:37:08 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 09:37:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 09:37:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 09:37:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 09:38:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 09:38:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 09:38:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 09:38:04 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 09:38:56 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 09:38:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 09:38:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 09:38:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 09:40:08 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 09:40:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 09:40:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 09:40:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 09:54:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 09:54:51 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 09:54:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 09:54:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 09:55:13 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 09:55:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 09:55:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 09:55:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 09:55:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 09:55:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 09:55:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 09:55:34 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 09:56:12 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 09:56:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 09:56:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 09:56:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 10:08:00 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 10:08:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 10:08:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 10:08:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 10:09:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 10:09:09 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 10:09:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 10:09:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 10:12:25 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 10:12:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 10:12:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 10:12:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 10:13:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 10:13:33 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 10:13:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 10:13:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 10:13:43 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 10:13:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 10:13:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 10:13:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 10:14:42 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 10:14:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 10:14:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 10:14:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 10:48:12 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 10:48:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 10:48:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 10:48:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 10:50:08 --> Query error: Unknown column 'menu_id' in 'where clause' - Invalid query: SELECT *
FROM `orders`
WHERE `user_id` = '3'
AND `menu_id` = 1
ERROR - 2020-03-07 10:50:16 --> Query error: Unknown column 'menu_id' in 'where clause' - Invalid query: SELECT *
FROM `orders`
WHERE `user_id` = '3'
AND `menu_id` = 1
ERROR - 2020-03-07 10:52:33 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 10:52:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 10:52:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 10:52:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 10:52:43 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 10:52:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 10:52:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 10:52:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 10:57:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 10:57:27 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 10:57:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 10:57:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 10:59:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 10:59:50 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 10:59:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 10:59:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 11:00:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 11:00:57 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 11:00:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 11:00:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 11:11:38 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 11:11:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 11:11:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 11:11:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 11:12:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 11:12:36 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 11:12:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 11:12:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 11:12:44 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\foodie\application\controllers\Menu.php 143
ERROR - 2020-03-07 11:13:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 11:13:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 11:13:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 11:13:12 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 11:13:57 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\foodie\application\controllers\Menu.php 143
ERROR - 2020-03-07 11:14:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 11:14:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 11:14:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 11:14:17 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 11:14:50 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 11:14:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 11:14:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 11:14:51 --> 404 Page Not Found: Assets/plugins
                                                                                                                                                                                                                                                                               ERROR - 2020-03-07 17:07:30 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 20:16:39 --> Severity: Notice --> Undefined variable: dataCount C:\xampp\htdocs\foodie\application\views\menu.php 7
ERROR - 2020-03-07 20:17:45 --> 404 Page Not Found: Admin/settings
ERROR - 2020-03-07 20:28:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 20:33:31 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 20:33:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 20:34:12 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 20:34:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 20:34:52 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 20:34:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 20:41:47 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 20:41:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 20:42:34 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 20:42:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 20:46:11 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 20:46:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 20:53:28 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 20:53:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 20:55:16 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 20:55:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 21:12:21 --> Severity: Notice --> Undefined index: price C:\xampp\htdocs\foodie\application\views\admin\admin_settings.php 15
ERROR - 2020-03-07 21:12:21 --> Severity: Notice --> Undefined index: time C:\xampp\htdocs\foodie\application\views\admin\admin_settings.php 23
ERROR - 2020-03-07 21:12:21 --> Severity: Notice --> Undefined index: time C:\xampp\htdocs\foodie\application\views\admin\admin_settings.php 27
ERROR - 2020-03-07 21:12:23 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 21:12:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 21:14:10 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 21:14:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 21:15:26 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 21:15:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 21:17:02 --> 404 Page Not Found: Admin/admin
ERROR - 2020-03-07 21:18:12 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 21:18:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 21:27:48 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 21:27:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 21:28:22 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 21:28:25 --> 404 Page Not Found: Admin/admin
ERROR - 2020-03-07 21:28:32 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 21:29:13 --> Severity: Notice --> Undefined variable: other_script C:\xampp\htdocs\foodie\application\views\admin\admin_settings.php 43
ERROR - 2020-03-07 21:29:15 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 21:29:30 --> Severity: Notice --> Undefined variable: other_script C:\xampp\htdocs\foodie\application\views\admin\admin_settings.php 43
ERROR - 2020-03-07 21:29:32 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 21:30:02 --> Severity: Notice --> Undefined variable: other_script C:\xampp\htdocs\foodie\application\views\admin\admin_settings.php 43
ERROR - 2020-03-07 21:30:04 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 21:31:17 --> Severity: Notice --> Undefined variable: other_script C:\xampp\htdocs\foodie\application\views\admin\admin_settings.php 43
ERROR - 2020-03-07 21:31:19 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 21:35:06 --> Severity: Notice --> Undefined variable: other_script C:\xampp\htdocs\foodie\application\views\admin\admin_settings.php 43
ERROR - 2020-03-07 21:35:08 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 21:48:10 --> Severity: Notice --> Undefined variable: other_script C:\xampp\htdocs\foodie\application\views\admin\admin_settings.php 43
ERROR - 2020-03-07 21:48:12 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 21:48:14 --> Severity: error --> Exception: Call to undefined method User_model::data_insert() C:\xampp\htdocs\foodie\application\controllers\Admin_settings.php 61
ERROR - 2020-03-07 21:48:44 --> Query error: Unknown column '{"price":"50","time":{"start":"","closing":""}}' in 'field list' - Invalid query: INSERT INTO `settings` (`{"price":"50","time":{"start":"","closing":""}}`) VALUES ('')
ERROR - 2020-03-07 21:50:35 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\foodie\application\views\admin\admin_settings.php 23
ERROR - 2020-03-07 21:50:37 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 21:51:25 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 21:51:41 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 21:53:02 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 22:00:46 --> Severity: error --> Exception: Call to undefined function get_settings() C:\xampp\htdocs\foodie\application\controllers\Admin_settings.php 22
ERROR - 2020-03-07 22:01:19 --> Severity: Notice --> Undefined property: mysqli::$data C:\xampp\htdocs\foodie\application\helpers\settings_helper.php 19
ERROR - 2020-03-07 22:01:19 --> Severity: Notice --> Undefined property: mysqli_result::$data C:\xampp\htdocs\foodie\application\helpers\settings_helper.php 19
ERROR - 2020-03-07 22:01:19 --> Severity: Notice --> Trying to get property 'data' of non-object C:\xampp\htdocs\foodie\application\helpers\settings_helper.php 19
ERROR - 2020-03-07 22:01:19 --> Severity: Notice --> Trying to get property 'data' of non-object C:\xampp\htdocs\foodie\application\helpers\settings_helper.php 19
ERROR - 2020-03-07 22:01:19 --> Severity: Notice --> Trying to get property 'data' of non-object C:\xampp\htdocs\foodie\application\helpers\settings_helper.php 19
ERROR - 2020-03-07 22:01:19 --> Severity: Notice --> Trying to get property 'data' of non-object C:\xampp\htdocs\foodie\application\helpers\settings_helper.php 19
ERROR - 2020-03-07 22:01:19 --> Severity: Notice --> Trying to get property 'data' of non-object C:\xampp\htdocs\foodie\application\helpers\settings_helper.php 19
ERROR - 2020-03-07 22:01:19 --> Severity: Notice --> Trying to get property 'data' of non-object C:\xampp\htdocs\foodie\application\helpers\settings_helper.php 19
ERROR - 2020-03-07 22:05:35 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 22:06:58 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 22:11:48 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 22:33:54 --> Severity: Notice --> Undefined property: mysqli::$id C:\xampp\htdocs\foodie\application\controllers\Admin.php 27
ERROR - 2020-03-07 22:33:54 --> Severity: Notice --> Undefined property: mysqli::$user_id C:\xampp\htdocs\foodie\application\controllers\Admin.php 28
ERROR - 2020-03-07 22:33:54 --> Severity: Notice --> Undefined property: mysqli::$menu_id C:\xampp\htdocs\foodie\application\controllers\Admin.php 29
ERROR - 2020-03-07 22:33:54 --> Severity: error --> Exception: Cannot use object of type CI_DB_mysqli_result as array C:\xampp\htdocs\foodie\application\controllers\Admin.php 26
ERROR - 2020-03-07 22:34:39 --> Severity: error --> Exception: Cannot use object of type CI_DB_mysqli_result as array C:\xampp\htdocs\foodie\application\controllers\Admin.php 26
ERROR - 2020-03-07 22:35:51 --> Severity: error --> Exception: Cannot use object of type CI_DB_mysqli_result as array C:\xampp\htdocs\foodie\application\controllers\Admin.php 26
ERROR - 2020-03-07 22:36:22 --> Severity: error --> Exception: Cannot use object of type CI_DB_mysqli_result as array C:\xampp\htdocs\foodie\application\controllers\Admin.php 27
ERROR - 2020-03-07 22:37:39 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 22:42:14 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 22:45:02 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\foodie\system\helpers\date_helper.php 418
ERROR - 2020-03-07 22:45:02 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\foodie\system\helpers\date_helper.php 418
ERROR - 2020-03-07 22:45:02 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\foodie\system\helpers\date_helper.php 418
ERROR - 2020-03-07 22:45:02 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\foodie\system\helpers\date_helper.php 422
ERROR - 2020-03-07 22:45:02 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\foodie\system\helpers\date_helper.php 422
ERROR - 2020-03-07 22:45:02 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\foodie\system\helpers\date_helper.php 436
ERROR - 2020-03-07 22:45:05 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 22:45:18 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 22:48:32 --> Severity: error --> Exception: Call to undefined function current_date() C:\xampp\htdocs\foodie\application\helpers\format_date_helper.php 91
ERROR - 2020-03-07 22:48:49 --> Severity: error --> Exception: Call to undefined function current_date() C:\xampp\htdocs\foodie\application\helpers\format_date_helper.php 91
ERROR - 2020-03-07 22:49:37 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 22:51:28 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 23:03:31 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-07 23:03:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-07 23:03:32 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 23:03:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 23:05:29 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-07 23:05:30 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-07 23:05:31 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 23:05:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 23:05:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-07 23:05:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-07 23:05:36 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 23:05:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 23:12:39 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 23:12:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-03-07 23:17:48 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 23:18:01 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 23:18:48 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 23:21:03 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 23:21:27 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 23:23:16 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 23:30:37 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 23:31:14 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 23:35:56 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 23:36:43 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 23:49:54 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 23:58:55 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-07 23:59:57 --> 404 Page Not Found: Assets/images
